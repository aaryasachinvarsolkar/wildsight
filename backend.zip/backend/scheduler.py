import sys
import os
import time
from datetime import datetime
from sqlmodel import Session, select

# Add backend to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.models.db import engine, RiskPrediction, PulseLog
from app.services.geospatial import geospatial_service
from app.services.ingest_gbif import gbif_service
from app.services.inference import inference_engine
from app.services.ml_trainer import MLTrainer

def run_pulse():
    print(f"[{datetime.now()}] --- Pulse Started (Continuous Learning Mode) ---")
    
    trainer = MLTrainer()
    
    # 1. Get List of Species (Dynamic from DB or Expanded List)
    # Ideally: select distinct species from UserInteractions
    species_list = ["Panthera tigris", "Elephas maximus", "Rhinoceros unicornis", "Diospyros ebenum", "Chlorophytum borivilianum"] 
    updated_count = 0
    new_knowledge_logs = []
    
    with Session(engine) as session:
        for species in species_list:
            print(f"Processing {species}...")
            
            # A. Fetch Real Locations (GBIF)
            # Limit to 10 for speed in demo loop
            occurrences = gbif_service.fetch_species_occurrences(species, limit=10)
            
            # [Fix] Fallback for species with 0 digital sightings (e.g. Ebony)
            if not occurrences:
                print(f"  [WARN] No GBIF data for {species}. Using Fallback Habitat.")
                # Default to Tadoba/Central India for Indian Species context
                occurrences = [(20.21, 79.31, "fallback_zone")]
            
            for (lat, lon, zone_id) in occurrences:
                import h3
                try:
                   h3_index = h3.geo_to_h3(lat, lon, 7)
                except:
                   h3_index = "unknown"

                # B. [Phase 3] MONITORING DATA (Live)
                # Instead of cached 'Habitat' data, we check 'Live' conditions
                monitoring_ndvi = geospatial_service.get_monitoring_data(lat, lon)
                
                # C. Detect Change / Risk
                # If Live NDVI < 0.4 (Stress) => High Risk Event
                risk_score = 0.2
                if monitoring_ndvi < 0.4:
                    risk_score = 0.8
                
                # D. Generate Pulse Log (Learning Moment)
                # We simulate an "Action" taken in response to this risk for the ML model to learn.
                action = "monitor"
                if risk_score > 0.7:
                    action = "field_intervention" 
                
                timestamp = datetime.utcnow()
                
                # 1. Add to List for ML Trainer (Immediate Learning)
                trainer_log = {
                    "species_name": species,
                    "risk_score": risk_score,
                    "ndvi_current": monitoring_ndvi,
                    "action": action,
                    "outcome": "success", 
                    "hdi": 0.5, "sens_fire": 0, "sens_poaching": 0, "sens_encroachment": 0, "sens_drought": 0,
                    "sens_disease": 0, "sens_power_lines": 0, "is_plant": 1 if "Diospyros" in species or "Chlorophytum" in species else 0,
                    "is_mammal": 1 if "Panthera" in species or "Elephas" in species else 0,
                    "is_bird": 0, "is_reptile": 0, "is_amphibian": 0, "is_insect": 0, "is_marine": 0, "is_fungi": 0
                }
                new_knowledge_logs.append(trainer_log)
                
                # 2. Add to DB for Frontend Graph (Historical Tracking)
                # [Fix] Restoring this is critical for the UI!
                db_log = PulseLog(
                    species_name=species,
                    h3_index=str(h3_index), # [Phase 3] Capture Location
                    timestamp=timestamp,
                    population_count=int(2500 * risk_score * 10), # Mock variation
                    risk_score=risk_score,
                    data_source="continuous_pipeline"
                )
                session.add(db_log)
                
                updated_count += 1
            
            session.commit()
            print(f"  [SAVED] {species} logs to DB.")

    print(f"[{datetime.now()}] --- Pulse Complete ---")
    print(f"Updates: {updated_count}")
    
    # E. TRIGGER RETRAINING
    if new_knowledge_logs:
        print(f"Triggering Continuous Learning Loop with {len(new_knowledge_logs)} new insights...")
        trainer.update_and_retrain(new_knowledge_logs)
    else:
        print("No new insights to learn from.")

if __name__ == "__main__":
    run_pulse()
