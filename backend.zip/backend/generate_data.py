import pandas as pd
import random
import os

# Define the "Knowledge Base" of Archetypes
# This maps biological traits and stressors to effective actions.
# This replaces hardcoded runtime rules with generated training data.

SPECIES_ARCHETYPES = [
    # --- AMPHIBIANS (Water Sensitive) ---
    {"class": "amphibia", "stressor": "drought", "action": "Construct_Artificial_Wetlands", "outcome": "success"},
    {"class": "amphibia", "stressor": "drought", "action": "Fire_Breaks", "outcome": "failure"}, # Bad action
    {"class": "amphibia", "stressor": "disease", "action": "Chytrid_Fungus_Monitoring", "outcome": "success"},
    {"class": "amphibia", "stressor": "pollution", "action": "Water_Filtration_System", "outcome": "success"},
    
    # --- BIRDS (Airspace / Nesting) ---
    {"class": "aves", "stressor": "power_lines", "action": "Install_Bird_Diverters", "outcome": "success"},
    {"class": "aves", "stressor": "power_lines", "action": "Reforestation", "outcome": "failure"}, # Irrelevant
    {"class": "aves", "stressor": "encroachment", "action": "Nesting_Site_Protection", "outcome": "success"},
    {"class": "aves", "stressor": "poaching", "action": "Anti_Trapping_Patrol", "outcome": "success"},
    
    # --- REPTILES (Thermoregulation / Habitat) ---
    {"class": "reptilia", "stressor": "temperature", "action": "Basking_Site_Restoration", "outcome": "success"},
    {"class": "reptilia", "stressor": "encroachment", "action": "Rock_Habitat_Preservation", "outcome": "success"},
    {"class": "reptilia", "stressor": "poaching", "action": "Anti_Trafficking_Unit", "outcome": "success"},

    # --- MAMMALS (Big Game / Conflict) ---
    {"class": "mammalia", "order": "carnivora", "stressor": "poaching", "action": "Anti_Poaching_Patrol", "outcome": "success"},
    {"class": "mammalia", "order": "herbivora", "stressor": "drought", "action": "Water_Hole_Construction", "outcome": "success"},
    {"class": "mammalia", "order": "proboscidea", "stressor": "encroachment", "action": "Human_Wildlife_Conflict_Barriers", "outcome": "success"}, # Elephants
    {"class": "mammalia", "order": "proboscidea", "stressor": "encroachment", "action": "Supplemental_Feeding", "outcome": "failure"}, # Creates conflict
    {"class": "mammalia", "order": "primates", "stressor": "disease", "action": "Zoonotic_Disease_Vaccination", "outcome": "success"},
    
    # --- PLANTS (Stationary / Fire) ---
    {"kingdom": "plantae", "stressor": "fire", "action": "Controlled_Burns", "outcome": "success"},
    {"kingdom": "plantae", "stressor": "encroachment", "action": "Protected_Zone_Demarcation", "outcome": "success"},
    {"kingdom": "plantae", "stressor": "logging", "action": "Anti_Logging_Patrol", "outcome": "success"},
    {"kingdom": "plantae", "stressor": "drought", "action": "Drip_Irrigation_Support", "outcome": "success"},
    
    # --- MARINE / ORGANISMS (Water Quality) ---
    {"class": "malacostraca", "stressor": "pollution", "action": "Ocean_Cleanup_Initiative", "outcome": "success"},
    {"class": "actinopterygii", "stressor": "overfishing", "action": "Marine_Protected_Area_Enforcement", "outcome": "success"},
    {"class": "chondrichthyes", "stressor": "poaching", "action": "Shark_Finning_Ban_Enforcement", "outcome": "success"},
    
    # --- INSECTS (Pollinators) ---
    {"class": "insecta", "stressor": "pesticides", "action": "Organic_Farming_Transition", "outcome": "success"},
    {"class": "insecta", "stressor": "habitat_loss", "action": "Pollinator_Corridor_Creation", "outcome": "success"},
    {"class": "insecta", "stressor": "climate_change", "action": "Microclimate_Restoration", "outcome": "success"},
    
    # --- FUNGI (Decomposers / Indicators) ---
    {"kingdom": "fungi", "stressor": "pollution", "action": "Mycoremediation_Deployment", "outcome": "success"},
    {"kingdom": "fungi", "stressor": "drought", "action": "Soil_Moisture_Conservation", "outcome": "success"},
    {"kingdom": "fungi", "stressor": "habitat_loss", "action": "Old_Growth_Forest_Protection", "outcome": "success"},
]

def generate_data(num_samples=5000):
    data = []
    
    for _ in range(num_samples):
        # Pick a random scenario
        archetype = random.choice(SPECIES_ARCHETYPES)
        
        # 1. Expand Traits to Features
        is_plant = 1 if archetype.get("kingdom") == "plantae" else 0
        is_animal = 1 if archetype.get("kingdom") != "plantae" and archetype.get("kingdom") != "fungi" else 0 # Simplified
        
        c = archetype.get("class", "")
        o = archetype.get("order", "")
        
        is_mammal = 1 if c == "mammalia" else 0
        is_bird = 1 if c == "aves" else 0
        is_reptile = 1 if c == "reptilia" else 0
        is_amphibian = 1 if c == "amphibia" else 0
        is_insect = 1 if c == "insecta" else 0
        is_marine = 1 if c in ["malacostraca", "actinopterygii", "chondrichthyes"] else 0
        is_fungi = 1 if archetype.get("kingdom") == "fungi" else 0
        
        # 2. Randomize Environmental Context
        risk_score = random.uniform(0.1, 0.95)
        hdi = random.uniform(0.1, 0.9) # Human Development Index
        
        # 3. Add to Dataset
        row = {
            "species_name": "Synthetic_Species", # Placeholder
            "primary_stressor": archetype["stressor"],
            "risk_score": round(risk_score, 2),
            "hdi": round(hdi, 2),
            "action": archetype["action"],
            "outcome": archetype["outcome"],
            
            # Detailed Features for ML
            "sens_fire": 1 if archetype["stressor"] == "fire" else 0,
            "sens_poaching": 1 if archetype["stressor"] == "poaching" else 0,
            "sens_encroachment": 1 if archetype["stressor"] == "encroachment" else 0,
            "sens_drought": 1 if archetype["stressor"] == "drought" else 0,
            "sens_disease": 1 if archetype["stressor"] == "disease" else 0,
            "sens_power_lines": 1 if archetype["stressor"] == "power_lines" else 0,
            
            # Biological Class Flags
            "is_plant": is_plant,
            "is_mammal": is_mammal,
            "is_bird": is_bird,
            "is_reptile": is_reptile,
            "is_amphibian": is_amphibian,
            "is_insect": is_insect,
            "is_marine": is_marine,
            "is_fungi": is_fungi
        }
        data.append(row)

    # Convert to DataFrame
    df = pd.DataFrame(data)
    
    # Save
    output_path = os.path.join(os.path.dirname(__file__), "app", "data", "intervention_history_augmented.csv")
    df.to_csv(output_path, index=False)
    print(f"Generated {num_samples} records to {output_path}")

if __name__ == "__main__":
    generate_data()
