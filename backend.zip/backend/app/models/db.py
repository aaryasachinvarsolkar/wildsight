from typing import Optional, List, Dict
from sqlmodel import Field, SQLModel, create_engine, Session, JSON
from datetime import datetime
import os

# --- Database Setup ---
# Use absolute path for reliability in this environment
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB_PATH = os.path.join(BASE_DIR, "wildsight.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(DATABASE_URL, echo=False)

def get_session():
    with Session(engine) as session:
        yield session

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

# --- Models ---

class RiskPrediction(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    species_name: str = Field(index=True)
    h3_index: str = Field(index=True)
    
    # Risk Assessment
    risk_level: str  # Low, Medium, High
    confidence: float
    explanation: str
    
    # Context (Snapshot for debugging)
    features_snapshot: Dict = Field(default={}, sa_type=JSON) 
    
    # Metadata
    model_version: str = Field(default="1.0.0")
    prediction_source: str = Field(default="computed") # "cached" or "computed"
    created_at: datetime = Field(default_factory=datetime.utcnow) 

class EnvironmentalCache(SQLModel, table=True):
    """
    Cache for environmental data per H3 cell to avoid re-fetching constantly.
    """
    h3_index: str = Field(primary_key=True)
    ndvi: float
    ndwi: float
    rainfall: float
    temperature: float
    human_development_index: float
    fetched_at: datetime = Field(default_factory=datetime.utcnow) 
    last_updated: datetime = Field(default_factory=datetime.utcnow)

class PulseLog(SQLModel, table=True):
    """
    Log of 5-day updates for species population and risk.
    """
    id: Optional[int] = Field(default=None, primary_key=True)
    species_name: str = Field(index=True)
    h3_index: Optional[str] = Field(default=None, index=True) # [Phase 3] Added for location-specific graphs
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    population_count: int
    risk_score: float
    data_source: str = "computed"


