from fastapi import APIRouter, HTTPException, Depends
from typing import List
import random
from datetime import datetime, timedelta
from sqlmodel import select, Session
from app.models.db import get_session, RiskPrediction
from app.services.geospatial import geospatial_service
from app.services.intelligence import anomaly_detector, habitat_model, prescription_engine, risk_estimator, AnomalyDetector, HabitatModel, PrescriptionEngine

# ... (rest of imports)


from app.models.schemas import ZoneAnalysis, RiskAssessment, EnvironmentalData, BiometricFeature, Prescription

router = APIRouter()

@router.get("/zones/risk/{z}/{x}/{y}") 
# Note: Ideally response_class=Response for binary MVT, but mocked as dict/json for now or using custom response
async def get_risk_tiles(z: int, x: int, y: int):
    """
    Returns Mapbox Vector Tiles (MVT) for risk zones.
    """
    tile_data = geospatial_service.get_tile(z, x, y)
    # In a real app, return Response(content=tile_data, media_type="application/x-protobuf")
    return {"message": "MVT Tile Placeholder", "coords": [z, x, y]}

@router.get("/species/{species_name}/occupancy")
async def get_species_occupancy(species_name: str, lat: float, lon: float):
    """
    Returns predicted occupancy probability.
    """
    env_data = geospatial_service.get_environmental_data(lat, lon)
    probability = habitat_model.predict_occupancy(species_name, env_data)
    return {
        "species": species_name,
        "location": {"lat": lat, "lon": lon},
        "occupancy_probability": probability,
        "environmental_factors": env_data
    }

@router.post("/predict/anomaly")
async def predict_anomaly(history: List[EnvironmentalData]):
    """
    Analyzes a time-series of environmental data to detect anomalies.
    """
    is_anomaly = anomaly_detector.detect_anomaly(history)
    return {"anomaly_detected": is_anomaly}

@router.get("/prescriptions/{h3_index}")
async def get_prescriptions(h3_index: str, species: str = "unknown", count: int = None, session: Session = Depends(get_session)):
    """
    Returns prescriptive conservation actions using the Trained ML Model.
    Enforces a 5-day cache policy for reproducibility and scalability.
    """
    # 0. Check Database Cache (Pulse Logic)
    try:
        statement = select(RiskPrediction).where(
            RiskPrediction.species_name == species,
            RiskPrediction.h3_index == h3_index
        ).order_by(RiskPrediction.created_at.desc())
        
        existing = session.exec(statement).first()
        
        # 5-Day Validity Check + Model Version Check
        if existing:
            age = datetime.utcnow() - existing.created_at
            # Invalidate if too old OR if model version suggests legacy data
            if age < timedelta(days=5) and existing.model_version == "2.0.0-RF":
                # Return Cached only if valid AND fresh
                return {
                    "zone": h3_index,
                    "risk_assessment": {
                        "risk_level": existing.risk_level,
                        "confidence": existing.confidence,
                        "explanation": existing.explanation,
                        "details": existing.features_snapshot
                    },
                    "recommended_actions": [Prescription(
                        action_type="Based on Risk Level", # Placeholder action
                        priority=existing.risk_level.lower(),
                        target_zone_h3=h3_index,
                        estimated_cost=0, 
                        expected_outcome="Cached Prediction",
                        description=existing.explanation
                    )],
                    "meta": {
                        "source": "cached", 
                        "age_hours": age.total_seconds() / 3600,
                        "model_version": existing.model_version,
                        "created_at": existing.created_at
                    }
                }
    except Exception as e:
        print(f"DB Read Error: {e}")

    # 1. Environment & Risk Simulation (If not cached)
    # Note: In a real flow, we would need lat/lon here to fetch weather.
    # Since H3 is provided, we can find center.
    try:
        import h3
        try:
            lat, lon = h3.h3_to_geo(h3_index)
        except AttributeError:
             # Support for h3-py v4+
            lat, lon = h3.cell_to_latlng(h3_index)
            
        env_data = geospatial_service.get_environmental_data(lat, lon)
        
        # 2. Risk Heuristic & Inference (New ML Engine)
        # 2. Risk Heuristic & Inference (New ML Engine)
        # Fetch Biological Sensitivity Profile
        from app.services.biometric import biometric_service
        species_data = biometric_service.get_species_data(species)
        sensitivities = species_data.get("sensitivities", {})
        
        # Calculate Risk using Math Engine
        risk = risk_estimator.estimate_risk(env_data, sensitivities)
        
        # Extract results
        risk_score = risk.risk_score
        primary_story = risk.primary_stressor
        
        # Call New Engine
        actions = prescription_engine.recommend_actions(risk, h3_index, species_name=species)
        
        # Take the top action or default
        best_action = actions[0] if actions else Prescription(
            action_type="Monitor", 
            priority="low", 
            description="No specific action recommended.", 
            target_zone_h3=h3_index, 
            estimated_cost=0, 
            expected_outcome="Monitoring"
        )
        
        # 3. Save to Database (Persistence)
        new_pred = RiskPrediction(
            species_name=species,
            h3_index=h3_index,
            risk_level="High" if risk_score > 0.6 else "Low",
            confidence=0.95,
            explanation=best_action.description, # Save the full report
            model_version="2.0.0-RF",
            prediction_source="computed",
            created_at=datetime.utcnow(),
            features_snapshot={"risk": risk_score, "stressor": primary_story}
        )
        session.add(new_pred)
        session.commit()
    
        # 4. Construct Response
        return {
            "zone": h3_index,
            "risk_assessment": {
                "risk_level": "High" if risk_score > 0.6 else "Low",
                "confidence": 0.95,
                "explanation": best_action.description,
                "details": {"risk": risk_score}
            },
            "recommended_actions": [best_action],
             "meta": {
                 "source": "computed",
                 "model_version": "2.0.0-RF",
                 "created_at": datetime.utcnow()
             }
        }
    except Exception as e:
        print(f"Compute Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
