from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse
import traceback
from typing import Dict, Any, List
from app.services.biometric import biometric_service
from app.services.geospatial import geospatial_service
from app.services.intelligence import prescription_engine, habitat_model, climate_predictor, trend_analyzer
from app.models.schemas import RiskAssessment

router = APIRouter()

@router.get("/test/hello")
async def hello():
    return {"message": "hello"}

import math
import numpy as np

def sanitize_response(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return 0.0
        return obj
    if isinstance(obj, dict):
        return {k: sanitize_response(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize_response(v) for v in obj]
    if isinstance(obj, np.generic): # Handle numpy scalars
        if np.isnan(obj) or np.isinf(obj):
            return 0.0
        return obj.item()
    return obj

@router.get("/{species_name}")
async def get_species_intelligence(
    species_name: str, 
    lat: float = None,
    lon: float = None,
    zone_id: str = Query(None, description="H3 Index for specific habitat filtering") # [Phase 3]
):
    try:
        # 1. Get Species Bio-Data (Checkpoints, Traits, etc.)
        # Now passing zone_id to filter 5-day pulse history
        bio_data = biometric_service.get_species_data(species_name, zone_id=zone_id)
        
        if not bio_data:
            # Species not found in "Real Life" (GBIF)
            raise HTTPException(status_code=404, detail=f"Species '{species_name}' not found in global biodiversity records.")

        checkpoints = bio_data.get("checkpoints", [])
        
        # Fallback if no location provided: Use Zone ID if available, else first checkpoint
        if lat is None or lon is None:
            if zone_id:
                try:
                    import h3
                    try:
                        lat, lon = h3.h3_to_geo(zone_id)
                    except AttributeError:
                        lat, lon = h3.cell_to_latlng(zone_id)
                    print(f"DEBUG: H3 Decoded to {lat}, {lon} for zone analysis")
                except Exception as e:
                    print(f"H3 Decode Failed: {e}")
            
            if (lat is None or lon is None) and checkpoints:
                lat = checkpoints[0]['lat']
                lon = checkpoints[0]['lon']
            
            # Absolute default
            if lat is None or lon is None:
                lat, lon = 20.5937, 78.9629 # Center of India default
        
        # 2. Get Environment Data for current location
        env_data = geospatial_service.get_environmental_data(lat, lon)
        
        # 3. Assess Risk (Determine the Narrative)
        risk_score = 0.2
        primary_stressor = "unknown"
        
        # Simple logical rules to determine the "story"
        if env_data.fire_radiative_power > 20:
            risk_score = 0.9
            primary_stressor = "fire"
        elif env_data.human_development_index > 0.6:
            risk_score = 0.8
            primary_stressor = "encroachment"
        elif env_data.rainfall_forecast_mm < 600:
            risk_score = 0.7
            primary_stressor = "drought"
        elif env_data.ndvi < 0.3:
            risk_score = 0.6
            primary_stressor = "habitat_loss"
            
        risk = RiskAssessment(
            risk_score=risk_score,
            primary_stressor=primary_stressor,
            anomaly_detected=(risk_score > 0.7),
            details={"ndvi": env_data.ndvi, "hdi": env_data.human_development_index}
        )

        # 4. Generate Explainable Data ( The "Evidence" )
        # Use the determined stressor to generate realistic history/forecasts
        
        # Historical Data (Vegetation, Disturbance) - Past 5 Years
        history_data = trend_analyzer.simulate_history(env_data, stressor=primary_stressor)
        
        # Forecast Data (Climate) - Next 5 Years
        forecast_data = climate_predictor.predict_future_scenario(env_data, stressor=primary_stressor)
        
        # 5. Get Prescriptions ( The "Solution" )
        actions = prescription_engine.recommend_actions(risk, "global_summary", species_name)
        
        # 6. Occupancy Probability
        ideal_env = bio_data.get("ideal_env")
        
        occupancy = habitat_model.predict_occupancy(species_name, env_data, ideal_config=ideal_env)

        # 7. Construct Final Response aligned with Frontend
        current_year = 2025 # Mock or real
        years_hist = [current_year - i for i in range(5, 0, -1)]
        years_forecast = forecast_data["years"]

        bio_data["analysis"] = {
            "vegetation": {
                "ndvi": history_data["ndvi"],
                "evi": history_data["evi"],
                "ndwi": history_data["ndwi"]
            },
            "climate": {
                "temp": forecast_data["temp"],
                "rain": forecast_data["rain"]
            },
            "disturbance": {
                "frp": history_data["frp"],
                "nightlight": history_data["nightlights"]
            }
        }
        # Add timeline metadata
        bio_data["years_history"] = years_hist
        bio_data["years_forecast"] = years_forecast
        # Legacy support (optional)
        bio_data["years"] = years_hist

        # [Refactor] Removed Duplicate PulseLog fetching.
        # It is now handled inside biometric_service.get_species_data(..., zone_id)
        
        response_data = {
            "species": bio_data,
            "environment_context": {
                "avg_ndvi": env_data.ndvi,
                "avg_temp": env_data.temperature_celsius,
                "avg_rain": env_data.rainfall_forecast_mm,
                "hdi": env_data.human_development_index,
                "risk_score": risk_score
            },
            "occupancy_probability": occupancy,
            "conservation_plan": [action.dict() for action in actions]
        }
        
        return sanitize_response(response_data)
    except HTTPException as he:
        # Re-raise HTTP exceptions so they propagate as intended (e.g. 404)
        raise he
    except Exception as e:
        print(f"Server Error: {e}")
        traceback.print_exc()
        return JSONResponse(
            status_code=500,
            content={"detail": str(e), "traceback": traceback.format_exc()}
        )
