from typing import List, Dict, Any
import random
import os
import math
import numpy as np
from sklearn.ensemble import IsolationForest, RandomForestClassifier, RandomForestRegressor
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from app.models.schemas import RiskAssessment, Prescription, EnvironmentalData
from app.services.biometric import biometric_service
from datetime import datetime

class AnomalyDetector:
    def __init__(self):
        # LOF for density-based local anomalies
        self.clf = LocalOutlierFactor(n_neighbors=20, novelty=True, contamination=0.1)
        self.is_fitted = False

    def detect_anomaly(self, history: List[EnvironmentalData]) -> bool:
        """
        Detects anomalies using Local Outlier Factor (LOF).
        """
        if not history or len(history) < 5:
             # Fallback simple rule
             if history and history[-1].fire_radiative_power > 50: return True
             return False
        
        # Feature Engineering: NDVI, Temp, Rain, Fire
        try:
            X = np.array([[d.ndvi, d.temperature_celsius, d.rainfall_forecast_mm, d.fire_radiative_power] for d in history])
            
            # Fit on history to learn "Normal" density
            self.clf.fit(X)
            self.is_fitted = True
            
            # Predict on observation (the last one)
            pred = self.clf.predict([X[-1]]) # 1 = Inlier, -1 = Outlier
            return pred[0] == -1
        except Exception as e:
            print(f"Anomaly Detection Error: {e}")
            return False

class RiskEstimator:
    """
    Mathematical Engine for Risk Calculation.
    Risk = Environment_Factor * Species_Sensitivity
    """
    def estimate_risk(self, env: EnvironmentalData, sensitivities: Dict[str, float]) -> RiskAssessment:
        # 1. Normalize Environmental Data (0.0 to 1.0)
        # High Values = High Stress Potential
        
        # Safe Access Helper
        def get_val(obj, attr, default=0.0):
            v = getattr(obj, attr, default)
            return 0.0 if v is None or math.isnan(v) else float(v)

        fp = get_val(env, 'fire_radiative_power', 0.0)
        rf = get_val(env, 'rainfall_forecast_mm', 0.0)
        tm = get_val(env, 'temperature_celsius', 25.0)
        hd = get_val(env, 'human_development_index', 0.4)
        nd = get_val(env, 'ndvi', 0.5)

        # Fire Potential (FRP > 50 is bad)
        factor_fire = min(fp / 50.0, 1.0)
        
        # Drought Potential (Rain < 800mm is bad)
        factor_drought = max(0.0, 1.0 - (rf / 1500.0))
        
        # Heat Potential (Temp > 35C is bad)
        factor_heat = max(0.0, (tm - 25.0) / 15.0) 
        
        # Encroachment Potential (HDI > 0.7 is bad)
        factor_hdi = max(0.0, (hd - 0.4) / 0.6) 
        
        # Habitat Loss Potential (NDVI < 0.3 is bad)
        factor_ndvi = max(0.0, 1.0 - (nd / 0.8))
        
        # 2. Apply Sensitivity Vectors
        # "Is this species bothered by this factor?"
        risk_vectors = {
            "fire": factor_fire * sensitivities.get("fire", 0.5),
            "drought": factor_drought * sensitivities.get("rainfall", 0.5),
            "heatwave": factor_heat * sensitivities.get("temp", 0.5),
            "encroachment": factor_hdi * sensitivities.get("hdi", 0.5),
            "habitat_loss": factor_ndvi * sensitivities.get("ndvi", 0.5)
        }
        
        # Sanitize Vectors
        for k, v in risk_vectors.items():
             if math.isnan(v): risk_vectors[k] = 0.0

        # ... (rest unchanged)

        # 3. Determine Primary Stressor
        primary_stressor = max(risk_vectors, key=risk_vectors.get)
        max_risk_score = risk_vectors[primary_stressor]
        
        is_anomaly = max_risk_score > 0.7
        
        return RiskAssessment(
            risk_score=round(max_risk_score, 2),
            primary_stressor=primary_stressor,
            anomaly_detected=is_anomaly,
            details=risk_vectors
        )
class HabitatModel:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=50, random_state=42)

    def predict_occupancy(self, species: str, env: EnvironmentalData, ideal_config: Dict = None) -> float:
        """
        Predicts suitability using a Random Forest trained on species-specific niches.
        If ideal_config is provided, we train the model on that niche on-the-fly.
        """
        
        # 1. Define Niche (Ground Truth)
        if ideal_config:
            ideal_ndvi = ideal_config.get('ndvi', 0.5)
            ideal_temp = ideal_config.get('temp', 25.0)
            ideal_rain = ideal_config.get('rainfall', 1000.0)
            ideal_hdi = ideal_config.get('hdi', 0.5)
            
            # Tolerances (could be passed in, but hardcoding reasonable defaults if missing)
            tol_ndvi = 0.2
            tol_temp = 5.0
            tol_rain = 500.0
        else:
            # Fallback if no config found (Generic Generalist)
            ideal_ndvi = 0.5
            ideal_temp = 25.0
            ideal_rain = 1000.0
            ideal_hdi = 0.5
            tol_ndvi = 0.4
            tol_temp = 10.0
            tol_rain = 1000.0

        # 2. Generate Training Data (Synthetic but Niche-based)
        # Positive Samples: Clustered around Ideal
        n_samples = 100
        # Ensure non-negative NDVI/Rain for realism, though RF doesn't care much
        X_pos = np.column_stack((
            np.random.normal(ideal_ndvi, tol_ndvi/2, n_samples),
            np.random.normal(ideal_temp, tol_temp/2, n_samples),
            np.random.normal(ideal_rain, tol_rain/2, n_samples),
            np.random.beta(2, 5, n_samples) # HDI, lower is generally better for wild animals
        ))
        y_pos = np.ones(n_samples)
        
        # Negative Samples: Random Background / Out of Niche
        X_neg = np.column_stack((
            np.random.uniform(0, 1, n_samples),
            np.random.uniform(-10, 45, n_samples),
            np.random.uniform(0, 3000, n_samples),
            np.random.uniform(0, 1, n_samples)
        ))
        y_neg = np.zeros(n_samples)
        
        # Combine
        X_train = np.vstack((X_pos, X_neg))
        y_train = np.hstack((y_pos, y_neg))
        
        # 3. Fit Random Forest
        # Ideally we cache this per species, but for <200 samples it's sub-millisecond
        self.model.fit(X_train, y_train)
        
        # 4. Predict on Current Environment
        curr = np.array([[
            getattr(env, 'ndvi', 0), 
            getattr(env, 'temperature_celsius', 25), 
            getattr(env, 'rainfall_forecast_mm', 0), 
            getattr(env, 'human_development_index', 0.5)
        ]])
        
        # Return probability of class 1
        try:
            return float(self.model.predict_proba(curr)[0][1])
        except:
            return 0.5

class PrescriptionEngine:
    def __init__(self):
        # Paths
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.model_path = os.path.join(base_dir, "models", "risk_model.pkl")
        
        self.model = None
        self.action_encoder = None
        self.feature_cols = []
        self.is_trained = False
        
        self._load_model()

    def _load_model(self):
        """
        Loads the pre-trained ML model and encoders.
        """
        try:
            import pickle
            if not os.path.exists(self.model_path):
                print(f"Warning: Model not found at {self.model_path}. Suggestions will be limited.")
                return 

            with open(self.model_path, "rb") as f:
                saved_artifacts = pickle.load(f)
                
            self.model = saved_artifacts["model"]
            self.action_encoder = saved_artifacts["action_encoder"]
            self.feature_cols = saved_artifacts["feature_cols"]
            self.is_trained = True
            print("ML Engine Loaded: Risk Model ready for inference.")
            
        except Exception as e:
            print(f"Error loading ML model: {e}")

    def _get_features(self, risk: RiskAssessment, species_meta: Dict) -> List[float]:
        """
        Transforms request into the Feature Vector used during training.
        Must match the columns in ml_trainer.py EXACTLY.
        """
        if not self.feature_cols:
            return []
            
        bio = species_meta.get("biological_traits", {})
        
        # 1. Biological Flags
        is_plant = 1 if bio.get("is_plant") else 0
        
        c = bio.get("class", "").lower()
        is_mammal = 1 if "mammalia" in c else 0
        is_bird = 1 if "aves" in c else 0
        is_reptile = 1 if "reptilia" in c else 0
        is_amphibian = 1 if "amphibia" in c else 0
        is_insect = 1 if "insecta" in c else 0
        is_marine = 1 if c in ["malacostraca", "actinopterygii", "chondrichthyes"] else 0
        is_fungi = 1 if bio.get("is_fungi") else 0
        
        # 2. Risk Sensitivities (Derived from Stressor for inference if explicit sens missing)
        # In a real app, these come from the species DB. We'll default to 0 or infer from the current stressor
        # to ensure the model sees a "relevant" scenario.
        stressor = risk.primary_stressor.lower()
        
        # Map values
        data = {
            "risk_score": risk.risk_score,
            "hdi": 0.5, # Default if missing
            "sens_fire": 1 if "fire" in stressor else 0,
            "sens_poaching": 1 if "poaching" in stressor else 0,
            "sens_encroachment": 1 if "encroachment" in stressor else 0,
            "sens_drought": 1 if "drought" in stressor else 0,
            "sens_disease": 1 if "disease" in stressor else 0,
            "sens_power_lines": 1 if "power" in stressor or "lines" in stressor else 0,
            "is_plant": is_plant,
            "is_mammal": is_mammal,
            "is_bird": is_bird,
            "is_reptile": is_reptile,
            "is_amphibian": is_amphibian,
            "is_insect": is_insect,
            "is_marine": is_marine,
            "is_fungi": is_fungi
        }
        
        # Convert to list in correct order
        return [data.get(col, 0) for col in self.feature_cols]

    def recommend_actions(self, risk: RiskAssessment, h3_index: str, species_name: str = "Species", population_count: int = None) -> List[Prescription]:
        """
        Predicts action using the Trained Model using pure inference.
        """
        if not self.is_trained:
             return [Prescription(
                action_type="General_Monitoring",
                priority="high",
                target_zone_h3=h3_index,
                estimated_cost=1000.0,
                expected_outcome="Data Gathering",
                description="The AI model is currently offline. Please restart the backend to load the trained model."
            )]

        # 1. Get Biological Context
        species_data = biometric_service.get_species_data(species_name) or {}
        
        # 2. Build Feature Vector
        features = self._get_features(risk, species_data)
        
        # 3. Predict & Generate Description
        try:
            # Get Probabilities
            probs = self.model.predict_proba([features])[0]
            
            # Get Top 3 suggestions for variety
            best_indices = np.argsort(probs)[-3:][::-1] # Reverse to get highest first
            
            predictions = []
            
            for idx in best_indices:
                conf = probs[idx]
                if conf < 0.05: continue # Skip very low confidence
                
                action_raw = self.action_encoder.inverse_transform([idx])[0]
                action_name = action_raw.replace("_", " ")
                
                # --- Detailed Report Generation ---
                desc = self._generate_detailed_plan(
                    action_name=action_name,
                    risk=risk,
                    species_name=species_name,
                    species_data=species_data,
                    population_count=population_count,
                    confidence=conf
                )

                predictions.append(Prescription(
                    action_type=action_raw,
                    priority="critical" if risk.risk_score > 0.7 or (population_count and population_count<500) else "high",
                    target_zone_h3=h3_index,
                    estimated_cost=5000 * (1+risk.risk_score),
                    expected_outcome=f"Mitigates threat of {risk.primary_stressor}",
                    description=desc
                ))
                
            return predictions

        except Exception as e:
            print(f"Inference Error: {e}")
            return []

    def _generate_detailed_plan(self, action_name: str, risk: RiskAssessment, species_name: str, species_data: Dict, population_count: int, confidence: float) -> str:
        """
        Generates a concise 4-point species-specific action plan.
        """
        bio = species_data.get("biological_traits", {})
        stressor = risk.primary_stressor.lower()
        
        # Determine Group for text tailoring
        group_label = "Species"
        if bio.get("is_plant"): group_label = "Flora"
        elif "mammalia" in bio.get("class", ""): group_label = "Mammal"
        elif "aves" in bio.get("class", ""): group_label = "Bird"
        elif "amphibia" in bio.get("class", ""): group_label = "Amphibian"
        
        # 1. ⚠️ Diagnosis (The Why)
        diagnosis = f"**{stressor.title()}** is the primary threat."
        if stressor == "drought":
            if group_label == "Amphibian": diagnosis = "Critical water scarcity is threatening cutaneous respiration and breeding pools."
            elif group_label == "Flora": diagnosis = "Hydraulic failure risk due to prolonged soil moisture deficit."
            else: diagnosis = "Dehydration stress is impacting foraging range and metabolic stability."
        elif stressor == "encroachment":
            if group_label == "Mammal": diagnosis = "Habitat fragmentation is severing migration corridors and increasing human-wildlife conflict."
            else: diagnosis = "Urban expansion is reducing viable nesting and foraging grounds."
        elif stressor == "fire":
             diagnosis = "High forest fire potential threatens to destroy critical canopy and ground cover."
        elif stressor == "poaching":
             diagnosis = "Illegal trafficking activity detected in the region, threatening population viability."
             
        # 2. 🛡️ Critical Intervention (The What Now)
        intervention = f"Implement **{action_name}** immediately."
        if group_label == "Amphibian" and "water" in action_name.lower():
            intervention = f"Deploy emergency **{action_name}** to maintain micro-habitat humidity."
        elif "corridor" in action_name.lower():
            intervention = f"Secure **{action_name}** to allow safe passage between fragmented habitats."
        elif stressor == "fire":
            intervention = f"Execute **{action_name}** protocols to create defensible space around key habitats."
            
        # 3. 🌿 Resilience Strategy (The Future)
        strategy = "Initiate long-term habitat restoration."
        if group_label == "Bird":
            strategy = "Restore native canopy trees to secure future nesting sites."
        elif group_label == "Amphibian":
            strategy = "Rehabilitate wetlands to buffer against future drought cycles."
        elif group_label == "Mammal":
            strategy = "Expand protected buffer zones to reduce edge effects."
        elif group_label == "Flora":
            strategy = "Establish ex-situ seed banks to preserve genetic diversity."
            
        # 4. 🤝 Community Role (The Human Factor)
        community = "Engage locals in monitoring."
        if stressor == "poaching":
            community = "Recruit local 'Guardian' units for community-led anti-poaching patrols."
        elif stressor == "encroachment":
            community = "Implement compensation schemes and education to mitigate human-wildlife conflict."
        elif group_label == "Bird":
             community = "Organize citizen science bird-watching events to track population trends."
        elif stressor == "fire":
             community = "Train local community response teams in early fire detection and suppression."
        else:
             community = "Conduct workshops on the ecological value of this species to verify local support."

        # Construct markdown
        md = f"### 1. ⚠️ Diagnosis\n{diagnosis}\n\n"
        md += f"### 2. 🛡️ Critical Intervention\n{intervention}\n\n"
        md += f"### 3. 🌿 Resilience Strategy\n{strategy}\n\n"
        md += f"### 4. 🤝 Community Role\n{community}"
        
        return md

class ClimatePredictor:
    # ...
    def predict_future_scenario(self, env: EnvironmentalData, stressor: str = "unknown") -> Dict[str, Any]:
        """
        Predicts future climate with specific stressor scenarios.
        """
        current_year = datetime.now().year
        years = [current_year + i for i in range(1, 6)] # Next 5 years
        
        def safe_get(val, default):
            return float(val) if val is not None and not math.isnan(val) else default

        base_temp = safe_get(env.temperature_celsius, 25.0)
        base_rain = safe_get(env.rainfall_forecast_mm, 1000.0)
        
        # ... logic ...
        temp_trend = []
        rain_trend = []
        
        temp_drift = 0.5
        rain_decay = 0.98
        
        if stressor == "drought":
            temp_drift = 1.2 
            rain_decay = 0.85 
        
        for i in range(5):
            # Temp
            t = base_temp + (i * temp_drift) + random.uniform(-0.2, 0.2)
            temp_trend.append(round(t, 1))
            
            # Rain
            r = base_rain * (rain_decay ** i) + random.uniform(-50, 50)
            rain_trend.append(max(0, round(r, 0)))
            
        return {
            "years": years,
            "temp": temp_trend,
            "rain": rain_trend
        }

class TrendAnalyzer:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.is_trained = False
        self._train_simulation()

    def _train_simulation(self):
        """
        Trains the forecaster.
        REMOVED: Synthetic Simulation Logic removed.
        """
        # self.is_trained = False
        pass

    def predict_trends(self, env: EnvironmentalData) -> Dict[str, List[float]]:
        if not self.is_trained:
            return {}
        
        # Prepare Input
        # [NDVI, Temp, Rain, HDI, FRP, NDWI]
        # Handle Nones safely
        x_in = [
            getattr(env, 'ndvi', 0.5),
            getattr(env, 'temperature_celsius', 25.0),
            getattr(env, 'rainfall_forecast_mm', 1000.0),
            getattr(env, 'human_development_index', 0.0),
            getattr(env, 'fire_radiative_power', 0.0),
            getattr(env, 'ndwi', 0.0)
        ]
        
        # Predict 20 values
        preds = self.model.predict([x_in])[0]
        
        # Unpack [5x NDVI, 5x EVI, 5x FRP, 5x Lights]
        return {
            "ndvi": [float(x) for x in preds[0:5]],
            "evi": [float(x) for x in preds[5:10]],
            "frp": [float(x) for x in preds[10:15]],
            "nightlights": [float(x) for x in preds[15:20]]
        }

    def simulate_history(self, env: EnvironmentalData, stressor: str = "unknown") -> Dict[str, List[float]]:
        """
        Generates realistic recent history data for the frontend charts.
        The data is tailored to the primary stressor detected.
        """
        # [v1.4] Location-Aware Seeding
        if env.h3_index:
            import hashlib
            # Create a stable seed from the H3 string
            seed_val = int(hashlib.md5(env.h3_index.encode()).hexdigest(), 16) % (2**32)
            random.seed(seed_val)

        # Base values from current env
        base_ndvi = env.ndvi if env.ndvi is not None else 0.5
        base_frp = env.fire_radiative_power if env.fire_radiative_power is not None else 5.0
        base_hdi = env.human_development_index if env.human_development_index is not None else 0.3
        
        # Trends
        ndvi_trend = []
        evi_trend = []
        ndwi_trend = []
        frp_trend = []
        lights_trend = []
        
        for i in range(5, 0, -1):
            # Simulate a 5-year history
            # Add some noise and stressor impact
            noise = random.uniform(-0.05, 0.05)
            
            # NDVI/EVI Trend
            status_impact = 0
            if stressor in ["drought", "habitat_loss", "fire"]:
                status_impact = -0.05 * i # Increasing stress leading to now
            
            nv = max(0, min(1, base_ndvi + status_impact + noise))
            ndvi_trend.append(round(nv, 2))
            evi_trend.append(round(nv * 0.8, 2))

            # NDWI Trend (Mirroring drought stress)
            base_ndwi = env.ndwi if env.ndwi is not None else 0.2
            wv = max(-1, min(1, base_ndwi + (status_impact * 1.5) + noise))
            ndwi_trend.append(round(wv, 2))
            
            # Fire Trend
            fv = base_frp
            if stressor == "fire" and i <= 2: # Recent fire activity
                fv = base_frp + random.uniform(20, 50)
            else:
                fv = max(0, fv + random.uniform(-5, 5))
            frp_trend.append(round(fv, 1))
            
            # Night Lights (Encroachment)
            lv = base_hdi * 10 
            if stressor == "encroachment":
                lv = lv - (0.5 * i) # Growing urban light
            lights_trend.append(round(max(0, lv + random.uniform(-0.5, 0.5)), 1))

        return {
            "ndvi": ndvi_trend,
            "evi": evi_trend,
            "ndwi": ndwi_trend,
            "frp": frp_trend,
            "nightlights": lights_trend
        }

# Instantiate services for export
prescription_engine = PrescriptionEngine()
habitat_model = HabitatModel()
anomaly_detector = AnomalyDetector()
climate_predictor = ClimatePredictor()
trend_analyzer = TrendAnalyzer()
risk_estimator = RiskEstimator()
