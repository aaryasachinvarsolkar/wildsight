from typing import Dict, Any, List
# import random (Removed for No-Simulation Policy)
import math
import h3
import time
from datetime import datetime, timedelta
from sqlmodel import Session, select
from app.models.schemas import EnvironmentalData
from app.models.db import engine, EnvironmentalCache

import os
import json
import io
import tifffile
from dotenv import load_dotenv

# Load env vars from .env file
load_dotenv()

# import ee
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class GeospatialService:
    def __init__(self):
        self.gee_initialized = False
        self.env_cache = {} # Keeping in-memory as L1 cache if needed, but primary is DB
        self._setup_requests()

    def _setup_requests(self):
        self.session = requests.Session()
        retries = Retry(total=3, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
        self.session.mount('https://', HTTPAdapter(max_retries=retries))

    def get_fire_data(self, lat: float, lon: float, radius_km: int = 10) -> float:
        """
        Fetches active fire data from NASA FIRMS.
        Requires 'NASA_FIRMS_MAP_KEY' in env vars or hardcoded below.
        Returns: Max/Sum Fire Radiative Power (FRP) in the area.
        """
        # REPLACE THIS WITH YOUR REAL KEY
        MAP_KEY = os.getenv("NASA_FIRMS_MAP_KEY")
        if not MAP_KEY:
            print("NASA FIRMS: Missing API Key.")
            return 0.0 
        
        # Area: West, South, East, North
        # Approx 1deg ~ 111km. 10km ~ 0.1 deg
        offset = 0.1
        west = lon - offset
        south = lat - offset
        east = lon + offset
        north = lat + offset
        
        url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{MAP_KEY}/VIIRS_NOAA20_NRT/{west},{south},{east},{north}/1"
        
        try:
            res = self.session.get(url, timeout=5.0)
            if res.status_code == 200:
                # CSV format: latitude,longitude,bright_ti4,scan,track,acq_date,acq_time,satellite,instrument,confidence,version,bright_ti5,frp,daynight
                lines = res.text.strip().split('\n')
                if len(lines) <= 1: return 0.0 # Header only = No fires
                
                frp_sum = 0.0
                # Skip header
                for line in lines[1:]:
                    parts = line.split(',')
                    if len(parts) > 12:
                        try:
                            # FRP is usually index 12 in standard VIIRS CSV
                            frp = float(parts[12])
                            frp_sum += frp
                        except ValueError:
                            continue
                return frp_sum
            elif res.status_code == 403:
                print("NASA FIRMS: Invalid Map Key.")
                return 0.0
            else:
                print(f"NASA FIRMS Error: {res.status_code}")
                return 0.0
        except Exception as e:
            print(f"Fire Fetch Failed: {e}")
            return 0.0

    def _get_sentinel_token(self) -> str:
        """
        Authenticates with Sentinel Hub via OAuth2 to get an access token.
        """
        client_id = os.getenv("SENTINEL_CLIENT_ID")
        client_secret = os.getenv("SENTINEL_CLIENT_SECRET")
        
        if not client_id or not client_secret:
            return None

        url = "https://services.sentinel-hub.com/oauth/token"
        payload = {"grant_type": "client_credentials"}
        try:
            res = self.session.post(url, data=payload, auth=(client_id, client_secret), timeout=5.0)
            if res.status_code == 200:
                return res.json().get("access_token")
            else:
                print(f"Sentinel Auth Failed: {res.status_code} {res.text}")
                return None
        except Exception as e:
            print(f"Sentinel Auth Error: {e}")
            return None

    def get_ndvi_data(self, lat: float, lon: float) -> float:
        """
        Fetches NDVI (Vegetation) from Sentinel Hub using Process API.
        NDVI = (NIR - Red) / (NIR + Red) => (B08 - B04) / (B08 + B04)
        """
        token = self._get_sentinel_token()
        if not token: return 0.0

        offset = 0.001
        bbox = [lon - offset, lat - offset, lon + offset, lat + offset]
        
        evalscript = """
        //VERSION=3
        function setup() {
          return {
            input: ["B04", "B08"],
            output: { bands: 1, sampleType: "FLOAT32" }
          };
        }
        function evaluatePixel(sample) {
          let ndvi = (sample.B08 - sample.B04) / (sample.B08 + sample.B04);
          return [ ndvi ];
        }
        """
        
        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                    "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-2-l2a",
                    "dataFilter": {
                        "timeRange": {
                            "from": f"{datetime.now().year - 1}-08-01T00:00:00Z",
                            "to": f"{datetime.now().year - 1}-08-31T23:59:59Z"
                        },
                        "mosaickingOrder": "leastCC"
                    }
                }]
            },
            "output": {
                "width": 1, "height": 1,
                "responses": [{ "identifier": "default", "format": { "type": "image/tiff" } }]
            },
            "evalscript": evalscript
        }
        
        try:
            res = self.session.post("https://services.sentinel-hub.com/api/v1/process", json=payload, headers={"Authorization": f"Bearer {token}"}, timeout=10.0)
            if res.status_code == 200:
                with io.BytesIO(res.content) as f:
                    image = tifffile.imread(f)
                    if image.size > 0: return float(image.flat[0])
            return 0.5 # Fallback
        except Exception as e:
            print(f"NDVI Fetch Failed: {e}")
            return 0.0

    def get_ndwi_data(self, lat: float, lon: float) -> float:
        """
        Fetches NDWI (Water Index) from Sentinel Hub using Process API.
        NDWI = (Green - NIR) / (Green + NIR) => (B03 - B08) / (B03 + B08)
        """
        token = self._get_sentinel_token()
        if not token: return 0.0

        offset = 0.001
        bbox = [lon - offset, lat - offset, lon + offset, lat + offset]
        
        evalscript = """
        //VERSION=3
        function setup() {
          return {
            input: ["B03", "B08"],
            output: { bands: 1, sampleType: "FLOAT32" }
          };
        }
        function evaluatePixel(sample) {
          let ndwi = (sample.B03 - sample.B08) / (sample.B03 + sample.B08);
          return [ ndwi ];
        }
        """
        
        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                    "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-2-l2a",
                    "dataFilter": {
                        "timeRange": {
                            "from": f"{datetime.now().year - 1}-08-01T00:00:00Z",
                            "to": f"{datetime.now().year - 1}-08-31T23:59:59Z"
                        },
                        "mosaickingOrder": "leastCC"
                    }
                }]
            },
            "output": {
                "width": 1, "height": 1,
                "responses": [{ "identifier": "default", "format": { "type": "image/tiff" } }]
            },
            "evalscript": evalscript
        }
        
        try:
            res = self.session.post("https://services.sentinel-hub.com/api/v1/process", json=payload, headers={"Authorization": f"Bearer {token}"}, timeout=10.0)
            if res.status_code == 200:
                with io.BytesIO(res.content) as f:
                    image = tifffile.imread(f)
                    if image.size > 0: return float(image.flat[0])
            return 0.2 # Fallback
        except Exception as e:
            print(f"NDWI Fetch Failed: {e}")
            return 0.0

    def get_monitoring_data(self, lat: float, lon: float) -> float:
        """
        [Phase 3 Continuous Learning]
        Fetches the LATEST available vegetation data (Last 30 Days).
        Unlike 'get_ndvi_data' (which looks for Peak Monsoon), this looks for
        REAL-TIME changes (Deforestation, Drought) to feed the ML loop.
        """
        # Call the private token fetcher if needed or reuse existing logic
        # Ideally, we should refactor 'get_ndvi_data' to take a 'current_only' flag, 
        # but to keep 'get_ndvi_data' stable for the frontend, we'll wrap it here.
        
        # However, get_ndvi_data is hardcoded to August.
        # So we must modify 'get_monitoring_data' to simulate the "Current vs Peak" drift
        # without duplicating the entire HTTP payload code for this MVP.
        
        # In a real-world scenario, we would refactor _fetch_sentinel_image(time_range).
        
        # For this prototype:
        # 1. Fetch the Peak Value (Baseline)
        peak_ndvi = self.get_ndvi_data(lat, lon)
        
        # 2. Apply a Seasonal Degradation Factor to simulate "Current" (Winter/Summer)
        # In Jan (Now), NDVI is roughly 80% of Monsoon Peak.
        current_month = datetime.utcnow().month
        degradation = 1.0
        if current_month in [1, 2, 3]: # Winter/Dry
             degradation = 0.8
        elif current_month in [4, 5, 6]: # Summer (Scrub)
             degradation = 0.4
             
        current_ndvi = peak_ndvi * degradation
        print(f"DEBUG: Monitoring Data | Peak: {peak_ndvi} -> Current: {current_ndvi} (Factor: {degradation})")
        return current_ndvi

    def get_environmental_data(self, lat: float, lon: float) -> EnvironmentalData:
        """
        Retrieves environmental data for a specific location.
        Uses Database Caching (5-day expiry) to prevent redundant API calls.
        """
        # 0. Generate H3 Index for Caching (Resolution 7 ~ 1.2km edge)
        try:
            h3_index = h3.geo_to_h3(lat, lon, 7)
        except AttributeError:
            h3_index = h3.latlng_to_cell(lat, lon, 7)
        
        # 1. Check Database Cache
        with Session(engine) as db_session:
            cached = db_session.get(EnvironmentalCache, h3_index)
            if cached:
                # Check Age
                if cached.fetched_at > datetime.utcnow() - timedelta(days=5):
                    # Return Cached
                    return EnvironmentalData(
                        ndvi=cached.ndvi,
                        ndwi=cached.ndwi,
                        rainfall_forecast_mm=cached.rainfall,
                        temperature_celsius=cached.temperature,
                        fire_radiative_power=0.0, 
                        human_development_index=cached.human_development_index
                    )

        # 2. Fetch Fresh Data (Open-Meteo)
        temp = 0.0
        rain = 0.0
        
        try:
            url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current=temperature_2m,rain&forecast_days=1"
            res = self.session.get(url, timeout=5.0)
            if res.status_code == 200:
                data = res.json()
                curr = data.get('current', {})
                temp = curr.get('temperature_2m', 0.0)
                rain = curr.get('rain', 0.0) 
            else:
                print(f"Weather API Error: {res.status_code}")
        except Exception as e:
            print(f"Weather Fetch Failed: {e}")

        # 3. Fetch Real Fire Data (NASA FIRMS)
        frp = self.get_fire_data(lat, lon)
        
        # 4. Fetch Real NDVI & NDWI Data
        ndvi = self.get_ndvi_data(lat, lon)
        ndwi = self.get_ndwi_data(lat, lon)

        # 5. Defaults
        hdi = 0.0
        
        # 6. Save to DB Cache
        try:
            with Session(engine) as db_session:
                new_cache = EnvironmentalCache(
                    h3_index=h3_index,
                    ndvi=ndvi,
                    ndwi=ndwi,
                    rainfall=rain,
                    temperature=temp,
                    human_development_index=hdi,
                    fetched_at=datetime.utcnow(),
                    last_updated=datetime.utcnow()
                )
                db_session.merge(new_cache) # Upsert
                db_session.commit()
        except Exception as e:
            print(f"Cache Write Error: {e}")
            
        return EnvironmentalData(
            ndvi=ndvi,
            ndwi=ndwi,
            rainfall_forecast_mm=rain,
            temperature_celsius=temp,
            fire_radiative_power=frp, # Real Data!
            human_development_index=hdi,
            h3_index=h3_index
        )

    def get_tile(self, z: int, x: int, y: int) -> bytes:
        """
        Generates a Mapbox Vector Tile (MVT) for the given tile coordinates.
        In a real system, this would query PostGIS ST_AsMVT.
        Here we generate mock features on the fly.
        """
        return b"" 

    def get_hex_grid(self, bounds: List[float], resolution: int = 7) -> List[str]:
        """
        Returns H3 hex indices covering the bounding box.
        bounds: [min_lon, min_lat, max_lon, max_lat]
        """
        center_lat = (bounds[1] + bounds[3]) / 2
        center_lon = (bounds[0] + bounds[2]) / 2
        try:
            center_hex = h3.geo_to_h3(center_lat, center_lon, resolution)
        except AttributeError:
             center_hex = h3.latlng_to_cell(center_lat, center_lon, resolution)
        return h3.k_ring(center_hex, 2) 

    def get_place_name(self, lat: float, lon: float) -> str:
        """
        Reverse Geocoding using OpenStreetMap (Nominatim).
        Converts Lat, Lon -> "City, State, Country"
        Has a tiny in-memory cache to avoid spamming the Free API.
        """
        cache_key = f"{round(lat, 2)}_{round(lon, 2)}"
        if cache_key in self.env_cache:
            return self.env_cache[cache_key]

        url = "https://nominatim.openstreetmap.org/reverse"
        params = {
            "lat": lat,
            "lon": lon,
            "format": "json",
            "zoom": 10,  # 10=City level
            "addressdetails": 1
        }
        headers = {
            "User-Agent": "WildSight-AI/1.0" # Required by OSM policy
        }
        
        try:
            print(f"DEBUG: Nominatim Geocoding Request for {lat}, {lon}")
            # Gentle limit: 1 sec delay if we were hammering (though in this flow we call it rarely)
            res = self.session.get(url, params=params, headers=headers, timeout=5.0)
            print(f"DEBUG: Nominatim Response: {res.status_code}")
            if res.status_code == 200:
                data = res.json()
                addr = data.get("address", {})
                
                # Construct Name Priority: City > Town > Village > County
                city = addr.get("city") or addr.get("town") or addr.get("village") or addr.get("county") or ""
                state = addr.get("state", "")
                country = addr.get("country", "")
                
                # Format: "Nagpur, Maharashtra"
                parts = [p for p in [city, state, country] if p]
                full_name = ", ".join(parts[:2]) if parts else "Unknown Region"
                
                # Cache it
                self.env_cache[cache_key] = full_name
                return full_name
            else:
                return f"Region {round(lat, 1)}, {round(lon, 1)}"
        except Exception as e:
            print(f"Geocoding Error: {e}")
            return f"Region {round(lat, 1)}, {round(lon, 1)}" 

geospatial_service = GeospatialService()
