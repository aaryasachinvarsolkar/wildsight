from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import router as api_router

app = FastAPI(
    title="EcoGuard Geospatial Intelligence Platform",
    description="Advanced AI-powered Geospatial Intelligence Platform for Biodiversity Conservation",
    version="1.0.0"
)

# CORS Configuration
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Welcome to EcoGuard API"}

app.include_router(api_router, prefix="/api/v1")
